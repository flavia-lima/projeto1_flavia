INSERT INTO `person` (`id`, `address`, `first_name`, `gender`, `last_name`) VALUES
	(1, 'Av Paulista', 'Flávia', 'Female', 'Lima'),
	(3, 'Rua dos Alfeneiros, 4', 'Harry', 'Male', 'Potter'),
	(4, 'Floresta Proibida', 'Lord', 'Male', 'Voldemort'),
	(5, 'Fenda do Biquini', 'Bob', 'Male', 'Esponja'),
	(6, 'Fenda do Biquini', 'Bob', 'Male', 'Esponja Calca Quadrada'),
	(7, 'Fenda do Biquini', 'Bob', 'Male', 'Esponja Calca Quadrada');